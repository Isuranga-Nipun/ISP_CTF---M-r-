<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
    // since the username is not set in session, the user is not-logged-in
    // he is trying to access this page unauthorized
    // so let's clear all session variables and redirect him to index
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}
?>

<?php
use Phppot\flag;

if (! empty($_POST["flag-btn"])) {
    require_once __DIR__ . '/Model/flag.php';
    $flagResponse = $flagStatus;

}
?>

<HTML>
<HEAD>
<TITLE>Level5</TITLE>
<link href="../assets/css/levelstyle.css" type="text/css" rel="stylesheet" />
<script src="../vendor/jquery/jquery-3.3.1.js" type="text/javascript"></script>
</HEAD>
<BODY>

<section class="banner">

	<div class="login-header">
        <div class="page-content">Welcome <b><?php echo $username;?></b></div>
    
        <div class="page-header">
            <span class="log-out">
                <a href="logout.php">Logout</a>
            </span>
        </div>       
    </div>



<img src="../assets/images/covers.jpg"></img>

<div class="horizontal-menu">
    <ul>
        <li><a href="../home.php">Home</a></li>
        <li><a href="level0.php">Level 0</a></li>
        <li><a href="level1.php">Level 1</a></li>
        <li><a href="level2.php">Level 2</a></li>
        <li><a href="level3.php">Level 3</a></li>
        <li><a href="level4.php">Level 4</a></li>
        <li><a href="level5.php" class="active">Level 5</a></li>
        <li><a href="level6.php">Level 6</a></li>
        <li><a href="../scoreboard.php">Scoreboard</a></li>
    </ul>
</div>

<div class="overlay"></div>

                <div class="hint-banner">
                    <h2>Level 5</h2>
                    
                    <div id="instruction">
                        <p>Download the file... look at the signature </p>
                        <center><a style="font-size:1.2em; background-color:lightgoldenrodyellow; padding: 6px; border:2px solid red; border-radius: 5px;" 
                            href="../levels/add_levels/lvl5/flag.zip" download="matrix">Download</a></center>
                    </div>
                    
                </div>
                <br>
                
    <div class="container">

        <div class="flag">
            <center><h3>Enter the Flag</h3></center>
            <br>

           <form name="flag" action="" method="post" onsubmit="return validateForm()">

            <?php if(!empty($flagResponse)){?>
                <div class="error-msg"><?php echo $flagResponse["message"]; ?></div>
            <?php }?>

            <center>            
            <div class="row">
                <div class="inline-block">
                    <div class="form-label">
                        Flag<span class="required error" id="flag-info"></span>
                    </div>
                    <input type="text" name="flag" id="flag" placeholder="Enter the flag here...">
                </div>    
            </div>

            <div class="row">
                <input type="hidden" value="<?php echo 5 ?>" name="flagid" id="flagid">
                <input type="hidden" value="<?php echo 5 ?>" name="levelid" id="levelid">
                <input type="hidden" value="<?php echo 10 ?>" name="flagpoint" id="flagpoint">
                <input type="submit"  value="Submit" id="flag-btn" name="flag-btn">
            </div>
            </center>
            </form>

        </div>
    </div>



</section>

<script>
    function validateForm() {
        var valid = true;
        $("#flag").removeClass("error-field");

        var flag = $("#flag").val();

        $("#flag-info").html("").hide();

        if (flag.trim() == "") {
            $("#flag-info").html("required.").css("color", "#ee0000").show();
            $("#flag").addClass("error-field");
            valid = false;
        }

        if (valid == false) {
            $('.error-field').first().focus();
            valid = false;
        }
        return valid;
    }
</script>



</BODY>
</HTML>
