<?php
require_once __DIR__ . "/index.php";
?>

<HTML>
<HEAD>
<TITLE>Matrix</TITLE>
<link href="assets/css/loginstyles.css" type="text/css" rel="stylesheet">
<script src="vendor/jquery/jquery-3.3.1.js" type="text/javascript"></script>
</HEAD>
<BODY>

	    <section class="banner">      
        
		<video src="assets/video/bg.mp4"muted loop autoplay></video>
	
		<div class="overlay"></div>
		<center>
			<div class="text">
				<h2>Matrix</h2>
				<h3>Do you inevitable...</h3>
				<p>Thomas Anderson, a computer programmer, is led to fight an underground 
				war <br> against powerful computers who have constructed his entire reality with 
				a system called the Matrix.</p>

				<a href="user-registration.php">Register</a>
				<a href="user-login.php">Get Start</a>
			</div>
		</center>

	 </section>

<script>
		function loginValidation() {
			var valid = true;
			$("#username").removeClass("error-field");
			$("#password").removeClass("error-field");

			var UserName = $("#username").val();
			var Password = $('#login-password').val();

			$("#username-info").html("").hide();

			if (UserName.trim() == "") {
				$("#username-info").html("required.").css("color", "#ee0000").show();
				$("#username").addClass("error-field");
				valid = false;
			}
			if (Password.trim() == "") {
				$("#login-password-info").html("required.").css("color", "#ee0000").show();
				$("#login-password").addClass("error-field");
				valid = false;
			}
			if (valid == false) {
				$('.error-field').first().focus();
				valid = false;
			}
			return valid;
		}
</script>
</BODY>
</HTML>
