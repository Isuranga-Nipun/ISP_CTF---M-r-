<?php
session_start();
if (isset($_SESSION["username"])) {
    $username = $_SESSION["username"];
    session_write_close();
} else {
    // since the username is not set in session, the user is not-logged-in
    // he is trying to access this page unauthorized
    // so let's clear all session variables and redirect him to index
    session_unset();
    session_write_close();
    $url = "./index.php";
    header("Location: $url");
}
?>

<HTML>
<HEAD>
<TITLE>Welcome</TITLE>
<link href="assets/css/homestyle.css" type="text/css"
	rel="stylesheet" />

</HEAD>
<BODY>

<section class="banner">


	<div class="login-header">
        <div class="page-content">Welcome <b><?php echo $username;?></b></div>
    
        <div class="page-header">
            <span class="log-out">
                <a href="logout.php">Logout</a>
            </span>
        </div>       
    </div>


<img src="assets/images/covers.jpg"></img>


<div class="horizontal-menu">
    <ul>
        <li><a href="home.php" class="active">Home</a></li>
        <li><a href="./levels/level0.php">Level 0</a></li>
        <li><a href="./levels/level1.php">Level 1</a></li>
        <li><a href="./levels/level2.php">Level 2</a></li>
        <li><a href="./levels/level3.php">Level 3</a></li>
        <li><a href="./levels/level4.php">Level 4</a></li>
        <li><a href="./levels/level5.php">Level 5</a></li>
        <li><a href="./levels/level6.php">Level 6</a></li>
        <li><a href="./levels/level7.php">Level 7</a></li>
        <li><a href="./levels/level8.php">Level 8</a></li>
        <li><a href="./scoreboard.php">Scoreboard</a></li>
    </ul>
</div>


<div class="overlay"></div>

<div class="text">
        <h3>Instructions</h3>
    <ul>
        <li> In every level you will get hints which will help you to complete the challeng </li>
        <li> You can jump into any level as you like </li>
        <li> Evely level has unique points according to the difficulty </li>
        <li> You can trace your progress in the "ScoreBoard" </li>
    </ul>
    <div class="start">
        <a href="./levels/level0.php">Start</a>
    </div>
</div>



</section>


    


</BODY>
</HTML>
