-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 16, 2020 at 09:32 AM
-- Server version: 10.1.47-MariaDB-0ubuntu0.18.04.1
-- PHP Version: 7.3.25-1+bionic

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `matr_isu`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_flag`
--

CREATE TABLE `tbl_flag` (
  `id` int(2) NOT NULL,
  `flag` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_flag`
--

INSERT INTO `tbl_flag` (`id`, `flag`) VALUES
(0, '0584bb2e45df252110b2d6c49f53d893'),
(1, 'asdasdsadasdasdasdasdasdasdasdasdasdasd'),
(2, 'asdasdasdascv332423423423sdfsdf'),
(3, '333a321bf54b7caff2eaed5d443380a6'),
(4, 'cd8f0586af5f80fe9baf9eee2d2acab2'),
(5, 'b2b7216c5053815ecf72959b5e5b9db0'),
(6, 'ad5b3c7fc10099769801b6303b770a5b');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

CREATE TABLE `tbl_member` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(255) NOT NULL,
  `lvl0` int(11) NOT NULL DEFAULT '0',
  `lvl1` int(11) NOT NULL DEFAULT '0',
  `lvl2` int(11) NOT NULL DEFAULT '0',
  `lvl3` int(11) NOT NULL DEFAULT '0',
  `lvl4` int(11) NOT NULL DEFAULT '0',
  `lvl5` int(11) NOT NULL DEFAULT '0',
  `lvl6` int(11) NOT NULL DEFAULT '0',
  `create_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_member`
--

INSERT INTO `tbl_member` (`id`, `username`, `password`, `email`, `lvl0`, `lvl1`, `lvl2`, `lvl3`, `lvl4`, `lvl5`, `lvl6`, `create_at`) VALUES
(13, 'ac', '$2y$10$x2Fa.dtOXsYV58bDFMfzX.1Kk4wcVatJKuJU1PMYRNglRQReCGwcK', 'ac@abs.com', 5, 5, 10, 10, 10, 10, 10, '2020-11-24 07:07:21'),
(21, 'isu', '$2y$10$ZoVGSCZjfgvvteMEb636AutpzKe1oOsNwdcsWflOC14x4fgwsjm3y', 'isu@gmail.com', 0, 0, 0, 10, 10, 10, 10, '2020-12-14 19:11:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_flag`
--
ALTER TABLE `tbl_flag`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_member`
--
ALTER TABLE `tbl_member`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_member`
--
ALTER TABLE `tbl_member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
